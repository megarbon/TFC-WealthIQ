package com.wealthiq.stockporfolio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StockporfolioApplicationTests {

	@Test
	void contextLoads() {
	}

}
