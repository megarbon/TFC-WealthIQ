package com.wealthiq.stockporfolio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StockporfolioApplication {

	public static void main(String[] args) {
		SpringApplication.run(StockporfolioApplication.class, args);
	}

}
