package com.unkownkoder;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuthenticatedBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
