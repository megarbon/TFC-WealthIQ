package com.irojas.demojwt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoJwtApplicationTests {

	@Test
	void contextLoads() {
	}

}
