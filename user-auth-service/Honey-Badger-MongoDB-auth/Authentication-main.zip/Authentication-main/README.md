## Authentication API

To install all the dependencies, run the following command:

```
npm install
```

To start the server, run the following command:

```
npm run dev
```
